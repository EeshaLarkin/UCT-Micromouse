# =========================================================================
# UCT Micromouse - Milestone 1, Step 2: Dual-Motor Speed Synchronization
# =========================================================================
# Goal: drive both wheels at matched speed using ONLY encoder feedback
# (no gyro yet -- that's Step 3). This also doubles as your encoder
# sanity check, since the motors -- not your hand -- are what actually
# turn the gearbox.
#
# Run this for a few seconds on the floor. Watch the printed tick counts:
#   - Both encL and encR should be increasing every loop (confirms the
#     encoders work -- if one stays at 0, that wheel's encoder wiring or
#     polarity needs checking before continuing).
#   - By the end, L_total and R_total should be close to each other.
#     If they're not, increase KP_BALANCE a bit and try again.
# =========================================================================
import uct_mouse

LOOP_MS = 20
RUN_TIME_MS = 3000       # short timed run, just to observe balancing
BASE_SPEED = 40
KP_BALANCE = 0.6          # P-gain on tick-rate imbalance -- start here, tune by feel


def clamp(value, lo, hi):
    return max(lo, min(hi, value))


def main():
    if not uct_mouse.init():
        print("Initialization failed.")
        return

    try:
        with open("polarity.txt", "r") as f:
            lines = f.read().strip().split(",")
            uct_mouse.set_polarity(int(lines[0]), int(lines[1]))
            if len(lines) >= 4:
                uct_mouse.set_encoder_polarity(int(lines[2]), int(lines[3]))
    except Exception:
        uct_mouse.set_polarity(1, 1)
        uct_mouse.set_encoder_polarity(1, 1)

    print("--- Step 2: Dual-Motor Speed Synchronization ---")

    last_l, last_r = uct_mouse.get_encoders()
    total_l, total_r = 0, 0
    elapsed_ms = 0

    while elapsed_ms < RUN_TIME_MS:
        l, r = uct_mouse.get_encoders()
        d_l = l - last_l
        d_r = r - last_r
        last_l, last_r = l, r
        total_l += d_l
        total_r += d_r

        # This loop's tick difference is a proxy for "which wheel is
        # currently spinning faster" -- exactly the P-controller idea:
        # correct in proportion to how big the current mismatch is.
        cross_error = d_l - d_r
        correction = KP_BALANCE * cross_error

        left_pwm = clamp(BASE_SPEED - correction, -100, 100)
        right_pwm = clamp(BASE_SPEED + correction, -100, 100)
        uct_mouse.set_motors(int(left_pwm), int(right_pwm))

        print(f"encL={l:6d} encR={r:6d}  d_l={d_l:+3d} d_r={d_r:+3d}  "
              f"correction={correction:+6.2f}  L_pwm={int(left_pwm):+4d} R_pwm={int(right_pwm):+4d}")

        uct_mouse.delay_ms(LOOP_MS)
        elapsed_ms += LOOP_MS

    uct_mouse.set_motors(0, 0)
    print()
    print(f"Done. L_total={total_l}  R_total={total_r}  "
          f"imbalance={abs(total_l - total_r)} ticks")


if __name__ == "__main__":
    main()