# =========================================================================
# UCT Micromouse - Milestone 1, Step 3: Closed-Loop Heading Correction
# =========================================================================
# Builds directly on Step 2. Two corrections are now combined into the
# same differential PWM adjustment:
#
#   1. Encoder balance (KP_BALANCE)  -- corrects INSTANTANEOUS wheel speed
#      mismatch, same as Step 2. Reacts fast, loop to loop.
#   2. Gyro heading (KH_HEADING)     -- corrects ACCUMULATED heading drift
#      that the encoder balance alone can't fully catch (this is exactly
#      what fixed the curving you saw in the simulator).
#
# Both corrections use the SAME sign convention: positive value means
# "slow the left wheel, speed up the right wheel" -- so they simply ADD
# together into one steer value before being applied.
#
# IMPORTANT: GYRO_SIGN is not yet calibrated on your hardware. Run this
# once and watch the mouse:
#   - If the curve gets BETTER (straighter) than Step 2 alone -> sign is right.
#   - If it curves WORSE or the wrong way -> flip GYRO_SIGN to -1 and rerun.
# =========================================================================

import uct_mouse
import utime

RUN_TIME_MS = 5000
LOOP_MS = 10
BASE_SPEED = 70          # matches your working Step 2 value (above dead-band)
KP_BALANCE = 3.0          # your best-performing Step 2 gain
KH_HEADING = 1.0          # P-only heading gain -- start small, tune up
GYRO_SIGN = 1              # flip to -1 if heading correction makes it worse


def clamp(value):
    return max(-100, min(value, 100))


def calibrate_gyro_bias(samples=100, sample_delay_ms=10):
    """Averages the gyro reading while stationary to remove sensor bias
    before it gets integrated into heading -- otherwise a small constant
    offset accumulates into fake 'drift' even when the mouse isn't moving."""
    print("Calibrating gyro bias -- keep the mouse still...")
    uct_mouse.set_motors(0, 0)
    total = 0.0
    for _ in range(samples):
        uct_mouse.delay_ms(sample_delay_ms)
        total += uct_mouse.get_gyro()
    bias = total / samples
    print(f"Gyro bias: {bias:+.4f} deg/s")
    return bias


def main():
    if not uct_mouse.init():
        print("Initialization failed.")
        return

    try:
        with open("polarity.txt", "r") as f:
            lines = f.read().strip().split(",")
            uct_mouse.set_polarity(int(lines[0]), int(lines[1]))
            if len(lines) >= 4:
                uct_mouse.set_encoder_polarity(int(lines[2]), int(lines[3]))
    except Exception:
        uct_mouse.set_polarity(1, 1)

    gyro_bias = calibrate_gyro_bias()

    print("--- Step 3: Encoder + Gyro Heading Correction ---")

    lenc0, renc0 = uct_mouse.get_encoders()
    heading_deg = 0.0
    last_time_ms = utime.ticks_ms()
    total_l, total_r = 0, 0
    time_elapsed = 0

    while time_elapsed < RUN_TIME_MS:
        # Real measured dt, same fix as the sensor test -- don't assume LOOP_MS.
        now_ms = utime.ticks_ms()
        dt_s = utime.ticks_diff(now_ms, last_time_ms) / 1000.0
        last_time_ms = now_ms

        # --- Encoder balance term (from Step 2, unchanged logic) ---
        lenc1, renc1 = uct_mouse.get_encoders()
        dl = lenc1 - lenc0
        dr = renc1 - renc0
        lenc0, renc0 = lenc1, renc1
        total_l += dl
        total_r += dr

        cross_error = dl - dr
        enc_correction = KP_BALANCE * cross_error

        # --- Gyro heading term (new) ---
        gyro_rate = (uct_mouse.get_gyro() - gyro_bias) * GYRO_SIGN
        heading_deg += gyro_rate * dt_s

        heading_error = 0.0 - heading_deg          # target heading is 0
        heading_correction = KH_HEADING * heading_error

        # --- Combine: same sign convention for both terms ---
        total_correction = enc_correction + heading_correction

        left_pwm = clamp(BASE_SPEED - total_correction)
        right_pwm = clamp(BASE_SPEED + total_correction)
        uct_mouse.set_motors(int(left_pwm), int(right_pwm))

        print(f"encL={lenc1:6d} encR={renc1:6d} d_l={dl:+3d} d_r={dr:+3d}  "
              f"heading={heading_deg:+7.2f}  enc_c={enc_correction:+6.2f} "
              f"head_c={heading_correction:+6.2f}  L={int(left_pwm):+4d} R={int(right_pwm):+4d}")

        uct_mouse.delay_ms(LOOP_MS)
        time_elapsed += LOOP_MS

    uct_mouse.set_motors(0, 0)
    print()
    print(f"Done. final_heading={heading_deg:+.2f} deg  "
          f"L_total={total_l}  R_total={total_r}  imbalance={abs(total_l - total_r)} ticks")


if __name__ == "__main__":
    main()