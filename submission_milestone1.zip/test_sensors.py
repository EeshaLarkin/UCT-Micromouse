# =========================================================================
# UCT Micromouse - Sensor Verification Script (Milestone 1, Step 1)
# =========================================================================
# Run this BEFORE writing any control logic. It just prints raw sensor
# values so you can confirm the hardware behaves as expected:
#   1. Push the mouse forward by hand -> both encoder counts should
#      increase, and by roughly the same amount.
#   2. Rotate the mouse 360 degrees by hand (slowly, on a stand so the
#      wheels don't drag on the floor) -> the printed integrated heading
#      should end up close to 360 degrees.
# =========================================================================
import uct_mouse

LOOP_MS = 20  # matches the control loop period we'll use later

def main():
    if not uct_mouse.init():
        print("Initialization failed.")
        return

    print("--- Sensor Verification ---")
    print("Push the mouse forward, then rotate it 360 deg. Ctrl+C to stop.")

    last_l, last_r = uct_mouse.get_encoders()
    heading_deg = 0.0

    while True:
        gyro_rate = uct_mouse.get_gyro()          # deg/s
        heading_deg += gyro_rate * (LOOP_MS / 1000.0)

        l, r = uct_mouse.get_encoders()
        dl = l - last_l
        dr = r - last_r
        last_l, last_r = l, r

        print(f"encL={l:6d} encR={r:6d}  (d_l={dl:+3d} d_r={dr:+3d})  "
              f"gyro_rate={gyro_rate:+7.2f} deg/s  heading={heading_deg:+8.2f} deg")

        uct_mouse.delay_ms(LOOP_MS)

if __name__ == "__main__":
    main()