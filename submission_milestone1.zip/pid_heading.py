# =========================================================================
# UCT Micromouse - Milestone 1: Run a Square (1m x 1m) (Framework)
# =========================================================================
# ASSIGNMENT DESCRIPTION:
# Implement a control loop to drive the mouse in a 1 meter by 1 meter square,
# turning 90 degrees at each corner, and returning to the start position.
# 
# KEY CONTROLS:
# - uct_mouse.set_motors(left_pwm, right_pwm) -> Set speed (-100 to 100)
# - uct_mouse.get_encoders() -> Returns (left_ticks, right_ticks)
# - uct_mouse.get_tof()      -> Returns (left_mm, center_mm, right_mm)
# - uct_mouse.delay_ms(ms)   -> Suspends execution and updates sensors
#
# GRADING:
# - The autograder applies 8% motor imbalance and 8% wheel slip.
# - Open-loop timing alone will accumulate errors. Use encoder and gyro
#   feedback to compensate.
# =========================================================================

import uct_mouse
import math

TICKS_PER_M = 5730
RUN_TIME_MS = 6000         #runs for 6 seconds
LOOP_MS = 10
BASE_SPEED = 85

KP_BALANCE = 2.5 

KP_HEADING = 1.5
KI_HEADING = 0.05
KD_HEADING = 0.3
GYRO_BIAS = 0.0

I_HEADING_LIM = 10
OUTPUT_LIM = 15
TURN_OUTPUT_LIM = 75

TURN_TARGET_DEG = 90.0
TURN_TOLERANCE_DEG = 1.0
SETTLE_LOOPS_REQ = 5
MIN_TURN_PWM = 70

KP_TURN = 1.25
KD_TURN = 0.6


# Clamp to stay within range
def clamp(value, low, high):
    return max(low, min(value, high))


def _sensor():
    # Returns sensor values and subtracts gyro bias
    lenc, renc = uct_mouse.get_encoders()
    gyro = uct_mouse.get_gyro() - GYRO_BIAS
    return lenc, renc, gyro


class PID:
    def __init__(self, kp, ki, kd, I_lim, output_lim):
        self.kp, self.ki, self.kd = kp, ki, kd
        self.I_lim = I_lim
        self.output_lim = output_lim
        self.integral = 0.0
        self.prev_error = 0.0

    def pid_output(self, error, dt_s):
        # Integral
        self.integral = clamp(self.integral + (error * dt_s), -self.I_lim, self.I_lim)
        # Derivative
        derivative = (error - self.prev_error)/dt_s
        self.prev_error = error

        output = (self.kp * error) + (self.ki * self.integral) + (self.kd * derivative)
        return clamp(output, -self.output_lim, self.output_lim)


def calibrate_gyro():
    """
    Calibrates the gyroscope Z-axis bias while the mouse is stationary.
    Collects 100 samples over 1.0 second (10ms intervals) to calculate average bias.
    """
    global GYRO_BIAS
    
    uct_mouse.set_motors(0, 0)
    
    # Sensor warm-up: let socket connection and telemetry stream stabilize (200ms)
    for _ in range(20):
        uct_mouse.delay_ms(10)
        
    GYRO_BIAS = 0.0  # Zero out bias during calibration run
    samples = []
    for _ in range(100):  # 100 samples at 10ms = 1.0 second
        uct_mouse.delay_ms(10)
        samples.append(uct_mouse.get_gyro())
        
    GYRO_BIAS = sum(samples) / len(samples)


def drive_straight(distance_m):
    #calibrate_gyro() # add back for hardware
    target_ticks = int(distance_m * TICKS_PER_M)

    heading_pid = PID(KP_HEADING, KI_HEADING, KD_HEADING, I_HEADING_LIM, OUTPUT_LIM )
    start_l, start_r, _ = _sensor()

    lenc0, renc0 = start_l, start_r
    time_elapsed = 0
    total_l, total_r = 0, 0
    dt = 0.01
    heading_deg = 0.0

    while time_elapsed <= RUN_TIME_MS:
        lenc1, renc1, gyro_rate = _sensor()
        dl = lenc1 - lenc0
        dr = renc1 - renc0
        lenc0, renc0 = lenc1, renc1
        total_l += dl
        total_r += dr

        avg = ((lenc1 - start_l) + (renc1 - start_r))/2.0
        if avg >= target_ticks:
            break

        # P-controller error correction
        cross_error = dl - dr
        enc_c = clamp(KP_BALANCE * cross_error, -OUTPUT_LIM, OUTPUT_LIM)

        heading_deg += gyro_rate * dt
        heading_error = 0.0 - heading_deg
        head_c = heading_pid.pid_output(heading_error, dt)
        
        correction = enc_c + head_c
        
        # Set pwm of each motor
        left_pwm = clamp(BASE_SPEED - correction, -100, 100)
        right_pwm = clamp(BASE_SPEED + correction, -100, 100)
        uct_mouse.set_motors(int(left_pwm), int(right_pwm))
        
        uct_mouse.delay_ms(LOOP_MS)
        time_elapsed += LOOP_MS

    uct_mouse.set_motors(0, 0)

    pass


def turn_left_90():
    turn_pid = PID(KP_TURN, 0.0, KD_TURN, 1.0, TURN_OUTPUT_LIM)
    heading_deg = 0.0
    dt = 0.01
    time_elapsed = 0
    settle_count = 0

    while time_elapsed <= RUN_TIME_MS:
        _, _, gyro_rate = _sensor()
        heading_deg += gyro_rate * dt
        heading_error = TURN_TARGET_DEG - heading_deg

        if abs(heading_error) <TURN_TOLERANCE_DEG:
            settle_count += 1
            uct_mouse.set_motors(0, 0)
            if settle_count >= SETTLE_LOOPS_REQ:
                break

        else:
            settle_count = 0
            output = turn_pid.pid_output(heading_error, dt)

            if 0 < abs(output) < MIN_TURN_PWM:
                output = MIN_TURN_PWM if output > 0 else -MIN_TURN_PWM

            left_pwm = clamp(-output, -100, 100)
            right_pwm = clamp (output, -100, 100)
            uct_mouse.set_motors(int(left_pwm), int(right_pwm))

        uct_mouse.delay_ms(LOOP_MS)
        time_elapsed += LOOP_MS

    uct_mouse.set_motors(0, 0)
    
    pass


def run_square():
    if not uct_mouse.init():
        print("Initialization failed.")
        return

    # Load polarity calibration if it exists
    try:
        with open("polarity.txt", "r") as f:
            lines = f.read().strip().split(",")
            uct_mouse.set_polarity(int(lines[0]), int(lines[1]))
            if len(lines) >= 4:
                uct_mouse.set_encoder_polarity(int(lines[2]), int(lines[3]))
    except Exception:
        uct_mouse.set_polarity(-1, -1)

    calibrate_gyro()

    for side in range(4):
        # 1. Drive forward 1 meter
        drive_straight(1.0)
        
        # 2. Turn 90 degrees left
        turn_left_90() # settles briefly within the function

    drive_straight(0.05)


if __name__ == "__main__":
    run_square()
